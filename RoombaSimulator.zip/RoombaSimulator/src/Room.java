//Sean Ristey

public class Room
{
    //Attributes
    private char[][] roomTiles = new char[9][26];
    private final String BOTTOM_ROW = "    a   b  c  d  e  f   g  h   i   j   k   l  m n  o  p  q   r  s   t   u  v  w  x   y  z";
    
    /**************************************************************************/
    
    //Constructor
    public Room()
    {
        //Populate roomTiles array with + characters
        for(int r = 0; r < roomTiles.length; r++)
        {
            for(int c = 0; c < roomTiles[r].length; c++)
            {
                roomTiles[r][c] = '+';
            }
        }
    }
    
    /**************************************************************************/
    
    /*roomToStr() Method: Creates a String that contains the room as it would
    appear in the Room Diagram TextArea*/
    public String roomToStr()
    {
        //Declare String to be returned
        String roomStr = "";
        
        //Iterate through the roomTiles array and construct a string version
        for(int r = 0; r < roomTiles.length; r++)
        {
            //Add numbers to the left of the array
            roomStr += Integer.toString(9 - r);
            
            for(int c = 0; c < roomTiles[r].length; c++)
            {
                roomStr += ("  " + roomTiles[r][c]);
            }
            
            //Add escape sequence to movel to next line
            roomStr += "\n";
        }
        
        //Add on the bottom row
        roomStr += BOTTOM_ROW;
        
        //Return the room as a String
        return roomStr;
    }
    
    /**************************************************************************/
    
    //addObstacle()
    public void addObstacle(Obstacle o)
    {
        for(int r = o.getPosR()-1; r > (o.getPosR() - o.getLength()-1); r--)
        {
            for(int c = o.getPosC(); c < (o.getPosC() + o.getHeight()); c++)
            {
                roomTiles[r][c] = 'o';
            }
        }
    }
}

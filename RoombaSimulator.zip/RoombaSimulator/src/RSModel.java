//Sean Ristey
public class RSModel
{
    //Attributes
    //Roomba robot = new Roomba();
    Room room = new Room();
    //Room roomDefault = new Room(1234567890);
    
    /**************************************************************************/

    //Constructor
    public RSModel()
    {
        //Generate a Room
        Room room = new Room();
    }
}

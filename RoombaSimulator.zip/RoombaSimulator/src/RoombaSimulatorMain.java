//Sean Ristey
public class RoombaSimulatorMain
{
    /*
    Within this program I have fully implemented the ability to add obstacles to
    the room diagram within the View.  Validation is partially complete but
    there are a few cases that I will ave to handle for Deliverable 3.
    
    To test the feature I promised in Proposal 2:
    
        1.) Compile and run
        2.) Type obstacle dimensions into the first box as described
        3.) Type the bottom corner of where your obstacle will go into second 
            box as described
        4.) Press the Add Obstacle Button and see your abstacle added in the
            room diagram
    */

    public static void main(String[] args)
    {
        /*Placed the declaration of RSModel and RSView into the RSController
        constructor to make main method cleaner */
        
        //Declare instance of Controller
        RSController cntrl = new RSController();
    }
    
}

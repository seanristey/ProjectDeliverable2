//Sean Ristey

//Imports
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.*;
//import java.awt.event.*;

public class RSView extends JFrame
{
    //Attributes
    private JTextArea roomDiagram;
    
    private JTextField obstacleSizeField;
    private JTextField obstaclePosField;
    private JButton addObstacleButton;
    
    private JButton startButton;
    private JButton pauseButton;
    private JButton resetButton;
    
    /**************************************************************************/
    
    //Constructor
    public RSView(RSModel model)
    {
        //Creating the properly size roomDiagram TextArea
        roomDiagram = new JTextArea(model.room.roomToStr(), 10, 31);
        
        //Creating the Fields / Button to input Obstacle attributes
        obstacleSizeField = new JTextField("lenghXheight, ex: 3x3", 15);
        obstaclePosField = new JTextField("bottom left corner, ex: g5", 15);
        addObstacleButton = new JButton("Add Obstacle");
        
        //Creating the Buttons used to control the Roomba / Room
        startButton = new JButton("Start");
        pauseButton = new JButton("Pause");
        resetButton = new JButton("Reset");
        
        //Creating Panels
        JPanel allContent = new JPanel();
        JPanel diagramContent = new JPanel();
        JPanel obstacleInputContent = new JPanel();
        JPanel controlButtonConent = new JPanel();
        
        setSize(750, 550);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(3, 1));
        
        //Adding the Area / Fields / Buttons to their respective Panels
        diagramContent.add(roomDiagram);
        
        obstacleInputContent.add(obstacleSizeField);
        obstacleInputContent.add(obstaclePosField);
        obstacleInputContent.add(addObstacleButton);
        
        controlButtonConent.add(startButton);
        controlButtonConent.add(pauseButton);
        controlButtonConent.add(resetButton);
        
        //Place all subpanels into the main panel
        add(diagramContent);
        add(obstacleInputContent);
        add(controlButtonConent);
        
        //Title of the Window
        this.setTitle("Roomba Simulator");
        
        //End program when user closes the window
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    /***************************************************************************
    Action Listeners for the JButtons*/
    
    //ActionListsner for addObstacleButton
    public void addObstacleButtonListener(ActionListener al) 
    {    
        addObstacleButton.addActionListener(al);
    }
    
    //ActionListener for startButton
    public void addStartButtonListener(ActionListener al)
    {
        startButton.addActionListener(al);
    }
    
    //ActionListener for pauseButton
    public void addPauseButtonListener(ActionListener al)
    {
        pauseButton.addActionListener(al);
    }
    
    //ActionListener for resetButton
    public void addResetButtonListener(ActionListener al)
    {
        resetButton.addActionListener(al);
    }
    
    /**************************************************************************/
    
    //setText() method for the obstacleSizeField
    public void setObstacleSizeFieldText(String str)
    {
        obstacleSizeField.setText(str);
    }
    
    //setText() method for the obstaclePosField
    public void setObstaclePosFieldText(String str)
    {
        obstaclePosField.setText(str);
    }
    
    /**************************************************************************/
    
    //setText() method for the roomDiagram TextArea
    public void updateRoomDiagram(String newRoomStr)
    {
        roomDiagram.replaceRange(newRoomStr, 0, newRoomStr.length());
    }
    
    /**************************************************************************/
    
    //getText methods for Obstacle fields
    public String getObstacleSizeFieldText()
    {
        return obstacleSizeField.getText();
    }
    
    public String getObstaclePosFieldText()
    {
        return obstaclePosField.getText();
    }
    
}

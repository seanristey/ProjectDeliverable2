//Sean Ristey

//Imports
import java.awt.event.*;

public class RSController
{
    //Attributes
    private RSView view;
    private RSModel model;
    
    /**************************************************************************/
    
    //Constructor
    public RSController()
    {
        //Declare the Model
        model = new RSModel();
        
        //Declare the View
        view = new RSView(model);
        
        view.setVisible(true);
        
        //Inner Class getObstacleButtonListener
        class getObstacleButtonListener implements ActionListener 
        {            
            public void actionPerformed(ActionEvent e)
            {
                /*in the future, this diagram will probably get the parameters
                from the obstacle fields and create a new object and add it
                to the room in the model*/
                
                String sizeInput = view.getObstacleSizeFieldText();
                //System.out.println(view.getObstacleSizeFieldText());
                String posInput = view.getObstaclePosFieldText();
                //System.out.println(view.getObstaclePosFieldText());
                
                //Validate input
                
                //Variables that will be used while validating input to create Obstacels
                boolean sizeInputValid = false;
                boolean posInputValid = false;
                int length = 0;
                int height = 0;
                int posCol = 0;
                int posRow = 0;
                
                //Validation for sizeInput
                //Determine if format is number, x, number
                if(sizeInput.length() == 3)
                {
                    if(Character.isDigit(sizeInput.charAt(0)) && sizeInput.charAt(1) == 'x' && Character.isDigit(sizeInput.charAt(2)))
                    {
                        //Verify that sizeInput is valid
                        sizeInputValid = true;
                        height = Integer.parseInt(sizeInput.substring(0,1));
                        length = Integer.parseInt(sizeInput.substring(2));
                    }
                }
                
                //Determine if format is number, number, x, number
                if(sizeInput.length() == 4)
                {
                    if(Character.isDigit(sizeInput.charAt(0)) && Character.isDigit(sizeInput.charAt(1)) && sizeInput.charAt(2) == 'x' && Character.isDigit(sizeInput.charAt(3)))
                    {
                        //Validate that first number is less than 25
                        int firstNum = Integer.parseInt(sizeInput.substring(0, 2));
                        
                        if(firstNum <= 25)
                        {
                            //Verify that sizeInput is valid
                            sizeInputValid = true;
                            height = firstNum;
                            length = Integer.parseInt(sizeInput.substring(3));
                        }
                    }
                }
                
                //Validation for posInput
                //Determine if format is letter, number
                if(posInput.length() == 2)
                {
                    if(Character.isLetter(posInput.charAt(0)) && Character.isDigit(posInput.charAt(1)))
                    {
                        //Verify that sizeInput is valid
                        posInputValid = true;
                        posCol = (int)posInput.charAt(0)-97;
                        posRow = Integer.parseInt(posInput.substring(1));
                    }
                }
                
                //Determine if format is letter, number, number
                if(posInput.length() == 3)
                {
                    if(Character.isLetter(posInput.charAt(0)) && Character.isDigit(posInput.charAt(1)) && Character.isDigit(posInput.charAt(2)))
                    {
                        //Verify that sizeInput is valid
                        posInputValid = true;
                        posCol = (int)posInput.charAt(0)-97;
                        posRow = Integer.parseInt(posInput.substring(1));
                    }
                }
                
                
                //Create an Obstacle if the input is valid
                if(sizeInputValid && posInputValid)
                {
                    int[] properRows = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0};
                    Obstacle o = new Obstacle(length, height, posCol, properRows[posRow]);
                    
                    view.setObstacleSizeFieldText("lenghxheight, ex: 3x3");
                    view.setObstaclePosFieldText("bottom left corner, ex: g5");
                    
                    //Add the obstacle to the room
                    model.room.addObstacle(o);
                    
                    //Update the roomdiagram
                    view.updateRoomDiagram(model.room.roomToStr());
                }
                
                //Display error if the input is invalid
                else
                {
                    view.setObstacleSizeFieldText("ERROR");
                    view.setObstaclePosFieldText("ERROR");
                }
            }
        }
        
        //Give control to Controller rather than view
        view.addObstacleButtonListener(new getObstacleButtonListener());
        
        //Inner Class getStartButtonListener
        class getStartButtonListener implements ActionListener 
        {            
            public void actionPerformed(ActionEvent e)
            {
                /*in the future, this diagram will probably get the parameters
                from the obstacle fileds and create a new object and add it
                to the room in the model*/
                
                //For now
                view.updateRoomDiagram("You pressed the Start Button");
            }
        }
        
        //Give control to Controller rather than view
        view.addStartButtonListener(new getStartButtonListener());
        
        //Inner Class getPauseButtonListener
        class getPauseButtonListener implements ActionListener 
        {            
            public void actionPerformed(ActionEvent e)
            {
                /*in the future, this diagram will probably get the parameters
                from the obstacle fileds and create a new object and add it
                to the room in the model*/
                
                //For now
                view.updateRoomDiagram("You pressed the Pause Button");
            }
        }
        
        //Give control to Controller rather than view
        view.addPauseButtonListener(new getPauseButtonListener());
        
        //Inner Class getResetButtonListener
        class getResetButtonListener implements ActionListener 
        {            
            public void actionPerformed(ActionEvent e)
            {
                /*in the future, this diagram will probably get the parameters
                from the obstacle fileds and create a new object and add it
                to the room in the model*/
                
                //For now
                view.updateRoomDiagram("You pressed the Reset Button");
            }
        }
        
        //Give control to Controller rather than view
        view.addResetButtonListener(new getResetButtonListener());
    }
    
    /**************************************************************************/
    
    //Methohds to pass data through Controller
    
    //getRoom()
    public String getRoom()
    {
        return this.model.room.roomToStr();
    }
    
    /**************************************************************************/
    
    //delay method
    
    public static void delay(int x)
    {
        try        
        {
            Thread.sleep(x*1000);
        } 
        
        catch (java.lang.InterruptedException ex)
        { 
            System.out.println(ex);
        }
    }
    
}

//Sean Ristey
public class Roomba
{
    //Attirbutes
    int rowPos = 8;
    int colPos = 0;
    int desiredRow = 8;
    char primaryDirection = 'r';
    
    //Constructor
    public Roomba()
    {
        //Nothing in here
    }
    
    /**************************************************************************/
    
    //clean method
    public void clean(Room r)
    {
        //Place the Roomba marker into the Room
        setRobotPosition(r);
        
        //Display the Marker in starting position
        System.out.println(r.roomToStr());
        
        //move to the designated side
        moveToSide(r);
    }
    
    /**************************************************************************/
    
    public void moveToSide(Room r)
    {
        //Clean to the right until the wall is reached
        if(primaryDirection == 'r' && colPos < 25)
        {
            //Clean current tile
            r.setTile(' ', rowPos, colPos);
            
            //Move to tile to the right
            colPos++;
            
            //Reset robot pos
            setRobotPosition(r);
            
            //Call trace if the next thing is an obstacle
            if((colPos + 1) < 24 && r.getRoomTiles()[rowPos][colPos+1] == 'o')
            {
                traceObstacle(r);
            }
            
            //print the room
            System.out.println(r.roomToStr());
            
            delay();
            
            //recall method
            moveToSide(r);
        }
        
        //Move up and clean left when the wall is hit from the right
        else if(primaryDirection == 'r' && colPos == 25)
        {
            //Terminate if on row 0
            if(rowPos == 0)
            {
                System.out.println("CLEANING COMPLETE");
                System.exit(0);
            }
            
            //Swap primary direction
            swapPrimaryDirection();
            
            //Change desired row
            decreaseDesiredRow(r);
            
            //move up
            moveUp(r);
        }
        
        else if(primaryDirection == 'l' && colPos > 0)
        {
            //Clean current tile
            r.setTile(' ', rowPos, colPos);
            
            //Move to tile to the left
            colPos--;
            
            //Reset robot pos
            setRobotPosition(r);
            
            //Call trace if the next thing is an obstacle
            if((colPos - 1) > 0 && r.getRoomTiles()[rowPos][colPos-1] == 'o')
            {
                traceObstacle(r);
            }
            
            //print the room
            System.out.println(r.roomToStr());
            
            delay();
            
            //recall method
            moveToSide(r);
        }
        
        //Move up and clean right when the wall is hit from the left
        else if(primaryDirection == 'l' && colPos == 0)
        {
            //Terminate if on row 0
            if(rowPos == 0)
            {
                System.out.println("CLEANING COMPLETE");
                System.exit(0);
            }
            
            //Swap primary direction
            swapPrimaryDirection();
            
            //Change desired row
            decreaseDesiredRow(r);
            
            //move up
            moveUp(r);
        }
        
        else
        {
            System.out.println("moveToSide is confused");
        }
    }
    
    /**************************************************************************/
    
    public void swapPrimaryDirection()
    {
        //Swap r to l
        if(primaryDirection == 'r')
        {
            primaryDirection = 'l';
        }
        
        //Swap l to r
        else
        {
            primaryDirection = 'r';
        }
    }
    
    /**************************************************************************/
    
    public void moveUp(Room r)
    {
        //Move up a row if able
        if(rowPos > 0)
        {
            //Clean current tile
            r.setTile(' ', rowPos, colPos);
            
            //Move up to desired row
            while(rowPos != desiredRow)
            {
                rowPos--;
                
                //set robot position
                setRobotPosition(r);
                
                //print the room
                System.out.println(r.roomToStr());
                
                //Delay
                delay();
                
                r.setTile(' ', rowPos, colPos);
            }
            
            //set robot position
            setRobotPosition(r);
            
            //print the room
            System.out.println(r.roomToStr());
            
            //Delay
            delay();
                        
            //Go back to moving sideways
            moveToSide(r);
        }
    }
    
    /**************************************************************************/
    
    public void traceObstacle(Room r)
    {
        //Move around the edge of an obstacle
        
        //Tracing right
        if((colPos + 1) < 24 && primaryDirection == 'r')
        {
            //Move down until you can move right
            while(r.getRoomTiles()[rowPos][colPos+1] == 'o')
            {
                //Move down a row
                moveDown(r);
                
                //Attempt to move over
                if(r.getRoomTiles()[rowPos][colPos+1] != 'o')
                {
                    //move right one tile
                    r.setTile(' ', rowPos, colPos);
                    colPos++;
                    setRobotPosition(r);
                    System.out.println(r.roomToStr());
                    delay();
                }
                
                //recall trace
                traceObstacle(r);
            }
            
            //Move to the right until there is no obstacle above
            if(r.getRoomTiles()[rowPos-1][colPos] == 'o')
            {
                //move the robot one block to the right
                r.setTile(' ', rowPos, colPos);
                colPos++;
                setRobotPosition(r);
                System.out.println(r.roomToStr());
                delay();
                
                //recall trace
                traceObstacle(r);
            }
            
            //otherwise move back up to the desired row
            else
            {
                moveUp(r);
            }
        }
        
        //Tracing right hits the wall
        else if((colPos + 1) == 25 && primaryDirection == 'r')
        {
            //switch direction
            swapPrimaryDirection();
            
            //Change desired row
            decreaseDesiredRow(r);
            
            //recall trace
            traceObstacle(r);
        }
        
        //Tracing to the left
        else if((colPos - 1) > 0 && primaryDirection == 'l')
        {
            //Move down until you can move right
            while(r.getRoomTiles()[rowPos][colPos-1] == 'o')
            {
                //Move down a row
                moveDown(r);
                
                //Attempt to move over
                if(r.getRoomTiles()[rowPos][colPos-1] != 'o')
                {
                    //move left one tile
                    r.setTile(' ', rowPos, colPos);
                    colPos--;
                    setRobotPosition(r);
                    System.out.println(r.roomToStr());
                    delay();
                }
                
                //recall trace
                traceObstacle(r);
            }
            
            //Move to the left until there is no obstacle above
            if(r.getRoomTiles()[rowPos-1][colPos] == 'o')
            {
                //move the robot one block to the left
                r.setTile(' ', rowPos, colPos);
                colPos--;
                setRobotPosition(r);
                System.out.println(r.roomToStr());
                delay();
                
                //recall trace
                traceObstacle(r);
            }
            
            //otherwise move back up to the desired row
            else
            {
                moveUp(r);
            }
        }
        
        //Tracing left hits the wall
        else if((colPos - 1) == 0 && primaryDirection == 'l')
        {
            //switch direction
            swapPrimaryDirection();
            
            //Change desired row
            decreaseDesiredRow(r);
            
            //recall trace
            traceObstacle(r);
        }
        
        else
        {
            System.out.println("TRACE IS CONFUSED");
        }
    }
    
    /**************************************************************************/
    
    public void moveDown(Room r)
    {
        //Basically the same as move up but with no alterations to desiredRow
        //Only called as part of trace
        if(rowPos < 8)
        {
            //Clean current tile
            r.setTile(' ', rowPos, colPos);
            
            //Increase rowPos (effectively moves the robot down on the diagram
            rowPos++;
            
            //set robot position
            setRobotPosition(r);
            
            //print the room
            System.out.println(r.roomToStr());
            
            //Delay
            delay();
        }
    }
    
    /**************************************************************************/
    
    public void decreaseDesiredRow(Room r)
    {
        //pretty obvious tbh
        desiredRow--;
    }
    
    /**************************************************************************/
    
    //setRobotPosition()
    public void setRobotPosition(Room r)
    {
        r.setTile('R', rowPos, colPos);
    }
    
    /**************************************************************************/
    
    public static void delay()
    {
        try        
        {
            Thread.sleep(250);
        } 
        
        catch (java.lang.InterruptedException ex)
        { 
            System.out.println(ex);
        }
    }
}

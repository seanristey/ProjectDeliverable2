//Sean Ristey
public class main
{
    /*
    This program demonstrates the execution of the Roomba cleaning algorithm that
    will be added to my MVC based program in Deliverable 3.  This program is able
    to successfully clean the room layouts I have tested but it will undergo
    more rigoruous testing before it is implemented in Deliverable 3.
    
    To see this program working as I said it would in Proposal 2:
    
        1.) Compile and run
        2.) Adjust the size of the output window so that it is easiest to see 
            the behavior of the algorithm
    
    The R represents the Roomba and it travels in a way that fully cleans the
    room while avoiding obstacles
    
    Uncomment lines 33 & 34 to add some additional obstacles to the room if you
    want!
    
    
    */

    public static void main(String[] args) {
        //Declaring a Room
        Room myRoom = new Room();
        
        //Declaring some Obstacles
        Obstacle o1 = new Obstacle(4, 6, 3, 7);
        Obstacle o2 = new Obstacle(4, 6, 20, 7);
        Obstacle o3 = new Obstacle(3, 3, 12, 5);
        
        //Placing the Obstacles in the Room
        myRoom.addObstacle(o1);
        //myRoom.addObstacle(o2);                   //Uncomment these lines for 
        //myRoom.addObstacle(o3);                   //additional obstacles
        
        //Display the Room
        System.out.println(myRoom.roomToStr());
        
        //Declare a Roomba
        Roomba robot = new Roomba();
        
        //Clean the Room
        robot.clean(myRoom);
    }
    
}

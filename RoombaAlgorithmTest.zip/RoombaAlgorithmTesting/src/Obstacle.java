//Sean Ristey
public class Obstacle
{
    //Attributes
    private int length;
    private int height;
    private int posR;
    private int posC;
    
    //Constructor
    public Obstacle(int length, int height, int posC, int posR)
    {
        this.length = length;
        this.height = height;
        this.posR = posR;
        this.posC = posC;
    }
    
    /**************************************************************************/
    
    //Getter Methods
    
    public int getLength() {
        return length;
    }

    public int getHeight() {
        return height;
    }

    public int getPosR() {
        return posR;
    }

    public int getPosC() {
        return posC;
    }
    
}
